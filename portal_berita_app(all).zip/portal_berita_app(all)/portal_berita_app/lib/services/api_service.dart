import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ApiService {
  // IP 10.0.2.2 adalah "localhost" khusus buat Android Emulator.
  // Jangan ganti ini kecuali lu pake HP asli (nanti gua ajarin kalau pake HP asli).
  final String baseUrl = 'http://10.0.2.2:8000/api';

// --- REGISTER (MODE DEBUG) ---
  Future<bool> register(String name, String email, String password) async {
    try {
      print('--- MULAI REQUEST REGISTER ---');
      final url = Uri.parse('$baseUrl/register');
      print('Menembak ke alamat: $url');

      final response = await http.post(
        url,
        body: {
          'name': name,
          'email': email,
          'password': password,
          'password_confirmation': password,
        },
        headers: {
          'Accept': 'application/json', // Penting biar Laravel tau ini minta JSON
        }
      );

      print('Status Code: ${response.statusCode}');
      print('Response Body: ${response.body}');

      if (response.statusCode == 201) {
        print('--- REGISTRASI SUKSES ---');
        return true;
      } else {
        print('--- REGISTRASI DITOLAK SERVER ---');
        return false;
      }
    } catch (e) {
      print('--- FATAL ERROR KONEKSI ---');
      print('Errornya: $e'); // <--- INI KUNCI JAWABANNYA
      return false;
    }
  }
  // --- LOGIN ---
  Future<bool> login(String email, String password) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/login'),
        body: {
          'email': email,
          'password': password,
        },
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        String token = data['access_token'];

        // Simpan token di memori HP
        SharedPreferences prefs = await SharedPreferences.getInstance();
        await prefs.setString('token', token);
        return true;
      } else {
        return false;
      }
    } catch (e) {
      return false;
    }
  }
// ... (kodingan register & login biarin aja)

  // --- AMBIL SEMUA BERITA (Untuk Home) ---
  Future<List<dynamic>> getNews() async {
    try {
      final response = await http.get(Uri.parse('$baseUrl/news'));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'];
      }
    } catch (e) {
      print("Error get news: $e");
    }
    return [];
  }

  // --- AMBIL DETAIL BERITA + KOMENTAR (Baru!) ---
  Future<Map<String, dynamic>?> getNewsDetail(int id) async {
    try {
      final response = await http.get(Uri.parse('$baseUrl/news/$id'));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data']; // Isinya berita + comments + user
      }
    } catch (e) {
      print("Error detail: $e");
    }
    return null;
  }

  // --- KIRIM KOMENTAR ---
  Future<bool> postComment(int newsId, String commentBody) async {
    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      String? token = prefs.getString('token');

      final response = await http.post(
        Uri.parse('$baseUrl/news/$newsId/comment'),
        headers: {
          'Authorization': 'Bearer $token', // Token Login
          'Accept': 'application/json',
        },
        body: {
          'body': commentBody,
        },
      );
      
      return response.statusCode == 200; // True kalau sukses
    } catch (e) {
      print("Error comment: $e");
      return false;
    }
  }
  
  // --- LOGOUT ---
  Future<void> logout() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.remove('token');
  }
}