import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../services/api_service.dart';

class DetailNewsScreen extends StatefulWidget {
  final int newsId;

  const DetailNewsScreen({super.key, required this.newsId});

  @override
  State<DetailNewsScreen> createState() => _DetailNewsScreenState();
}

class _DetailNewsScreenState extends State<DetailNewsScreen> {
  final ApiService _apiService = ApiService();
  final TextEditingController _commentController = TextEditingController();
  Map<String, dynamic>? newsData;
  bool isLoading = true;
  bool isSendingComment = false; // Buat loading pas kirim komen

  @override
  void initState() {
    super.initState();
    _fetchDetail();
  }

  void _fetchDetail() async {
    final data = await _apiService.getNewsDetail(widget.newsId);
    setState(() {
      newsData = data;
      isLoading = false;
    });
  }

  void _sendComment() async {
    if (_commentController.text.trim().isEmpty) return;
    
    setState(() => isSendingComment = true); // Mulai loading
    FocusScope.of(context).unfocus(); // Tutup keyboard

    bool success = await _apiService.postComment(widget.newsId, _commentController.text);
    
    setState(() => isSendingComment = false); // Selesai loading

    if (success) {
      _commentController.clear();
      _fetchDetail(); // Refresh komentar
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Komentar berhasil dikirim!"), backgroundColor: Colors.green),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Gagal mengirim komentar."), backgroundColor: Colors.red),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    if (newsData == null) {
      return Scaffold(
        appBar: AppBar(title: const Text("Error")),
        body: const Center(child: Text("Gagal memuat berita.")),
      );
    }

    // --- UI KEKINIAN MENGGUNAKAN SLIVER ---
    return Scaffold(
      backgroundColor: Colors.white,
      body: CustomScrollView(
        slivers: [
          // 1. APP BAR YANG BISA DI-SCROLL (HERO IMAGE)
          SliverAppBar(
            expandedHeight: 300.0, // Tinggi gambar pas dibuka
            floating: false,
            pinned: true, // AppBar tetep nempel di atas pas discroll
            backgroundColor: Colors.white,
            elevation: 0,
            flexibleSpace: FlexibleSpaceBar(
              centerTitle: true,
              title: Text(
                newsData!['title'], // Judul muncul di appbar pas discroll ke atas
                style: GoogleFonts.poppins(
                    color: Colors.black87, 
                    fontSize: 16, 
                    fontWeight: FontWeight.w600
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              background: Stack(
                fit: StackFit.expand,
                children: [
                  Image.network(
                    newsData!['image'] ?? 'https://via.placeholder.com/300',
                    fit: BoxFit.cover,
                    errorBuilder: (c, e, s) => Container(color: Colors.grey[300], child: const Icon(Icons.broken_image)),
                  ),
                  // Gradien hitam di bawah gambar biar tulisan kebaca
                  const DecoratedBox(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment(0.0, 0.5),
                        end: Alignment(0.0, 0.0),
                        colors: <Color>[
                          Color(0x60000000),
                          Color(0x00000000),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),

          // 2. ISI BERITA & KOMENTAR
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Judul Besar di bawah gambar
                  Text(
                    newsData!['title'],
                    style: GoogleFonts.poppins(fontSize: 24, fontWeight: FontWeight.bold, height: 1.2),
                  ),
                  const SizedBox(height: 10),
                  // Info Penulis & Tanggal
                  Row(
                    children: [
                      const CircleAvatar(
                        radius: 15,
                        backgroundColor: Colors.blueAccent,
                        child: Icon(Icons.person, size: 18, color: Colors.white),
                      ),
                      const SizedBox(width: 10),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(newsData!['author'], style: GoogleFonts.poppins(fontWeight: FontWeight.w600)),
                          Text("Diposting baru-baru ini", style: GoogleFonts.poppins(fontSize: 12, color: Colors.grey)),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 25),
                  // Isi Berita
                  Text(
                    newsData!['content'],
                    style: GoogleFonts.poppins(fontSize: 16, height: 1.6, color: Colors.black87),
                  ),
                  
                  const Divider(height: 50, thickness: 1),

                  // --- BAGIAN KOMENTAR KEKINIAN ---
                  Text("Komentar (${newsData!['comments'].length})", style: GoogleFonts.poppins(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 20),

                  // List Komentar
                  ListView.builder(
                    shrinkWrap: true, // Penting biar bisa di dalam ScrollView
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: newsData!['comments'].length,
                    itemBuilder: (context, index) {
                      final comment = newsData!['comments'][index];
                      // Desain bubble chat untuk komentar
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 15.0),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            CircleAvatar(
                              backgroundColor: Colors.grey[300],
                              child: Text(comment['user']['name'][0].toUpperCase(), style: GoogleFonts.poppins(fontWeight: FontWeight.bold)),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Container(
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: Colors.grey[100],
                                  borderRadius: const BorderRadius.only(
                                    topRight: Radius.circular(15),
                                    bottomLeft: Radius.circular(15),
                                    bottomRight: Radius.circular(15),
                                  ),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(comment['user']['name'], style: GoogleFonts.poppins(fontWeight: FontWeight.bold, fontSize: 13)),
                                    const SizedBox(height: 4),
                                    Text(comment['body'], style: GoogleFonts.poppins(fontSize: 14)),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                  
                  if (newsData!['comments'].isEmpty)
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 20),
                      child: Center(child: Text("Belum ada komentar. Jadilah yang pertama!", style: GoogleFonts.poppins(color: Colors.grey))),
                    ),
                  
                  // Ruang kosong di bawah biar input field gak ketutupan banget
                  const SizedBox(height: 80),
                ],
              ),
            ),
          ),
        ],
      ),

      // 3. INPUT FIELD KOMENTAR YANG MENGAMBANG DI BAWAH
      bottomSheet: Container(
        padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10, offset: const Offset(0, -5))],
        ),
        child: SafeArea(
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _commentController,
                  decoration: InputDecoration(
                    hintText: "Tulis komentar...",
                    contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(30), borderSide: BorderSide.none),
                    filled: true,
                    fillColor: Colors.grey[100],
                  ),
                ),
              ),
              const SizedBox(width: 10),
              // Tombol kirim dengan efek loading
              InkWell(
                onTap: isSendingComment ? null : _sendComment,
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(color: Colors.blueAccent, shape: BoxShape.circle),
                  child: isSendingComment
                      ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                      : const Icon(Icons.send_rounded, color: Colors.white),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}